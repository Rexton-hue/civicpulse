// npm run seed  ->  adds demo users/grievances if the database is empty.
const { openDb } = require('../src/db');
const { seedIfEmpty } = require('../src/seed');

const db = openDb();
console.log(seedIfEmpty(db) ? 'Demo data created.' : 'Database already has users, nothing seeded.');
