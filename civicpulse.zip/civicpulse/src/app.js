const path = require('path');
const express = require('express');
const { logger, notFound, errorHandler } = require('./middleware');

function createApp(db) {
  const app = express();
  app.disable('x-powered-by');
  app.use(logger);
  app.use(express.json({ limit: '100kb' }));

  app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
  app.use('/api/auth', require('./routes/auth')(db));
  app.use('/api/track', require('./routes/track')(db));
  app.use('/api/grievances', require('./routes/grievances')(db));
  app.use('/api', notFound); // unknown API paths get JSON, not HTML

  app.use(express.static(path.join(__dirname, '..', 'public')));
  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
