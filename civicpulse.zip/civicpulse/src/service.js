// Database helpers shared by routes and the seed script.

function toIso(sqliteTime) {
  return sqliteTime ? sqliteTime.replace(' ', 'T') + 'Z' : null;
}

function formatGrievance(row) {
  return {
    id: row.id,
    trackingId: row.tracking_id,
    title: row.title,
    description: row.description,
    category: row.category,
    location: row.location,
    status: row.status,
    submittedBy: { id: row.user_id, name: row.user_name },
    createdAt: toIso(row.created_at),
    updatedAt: toIso(row.updated_at),
  };
}

function formatHistory(rows) {
  return rows.map((h) => ({
    status: h.status,
    remark: h.remark,
    changedBy: h.changed_by_name || null,
    at: toIso(h.created_at),
  }));
}

function getHistory(db, grievanceId) {
  return formatHistory(
    db
      .prepare(
        `SELECT h.*, u.name AS changed_by_name
           FROM history h LEFT JOIN users u ON u.id = h.changed_by
          WHERE h.grievance_id = ? ORDER BY h.id ASC`
      )
      .all(grievanceId)
  );
}

function getGrievanceRow(db, id) {
  return db
    .prepare(
      `SELECT g.*, u.name AS user_name
         FROM grievances g JOIN users u ON u.id = g.user_id
        WHERE g.id = ?`
    )
    .get(id);
}

function createGrievance(db, userId, data) {
  const tx = db.transaction(() => {
    const info = db
      .prepare('INSERT INTO grievances (user_id, title, description, category, location) VALUES (?, ?, ?, ?, ?)')
      .run(userId, data.title.trim(), data.description.trim(), data.category, (data.location || '').trim());
    const id = Number(info.lastInsertRowid);
    const trackingId = 'GRV-' + String(id).padStart(4, '0');
    db.prepare('UPDATE grievances SET tracking_id = ? WHERE id = ?').run(trackingId, id);
    db.prepare('INSERT INTO history (grievance_id, status, remark, changed_by) VALUES (?, ?, ?, ?)').run(
      id,
      'Submitted',
      'Grievance registered',
      userId
    );
    return id;
  });
  return tx();
}

module.exports = { toIso, formatGrievance, formatHistory, getHistory, getGrievanceRow, createGrievance };
