// SQLite through Node's built-in `node:sqlite` module (Node 22.13+).
// No native add-on to compile, so `npm install` works on Windows, macOS, Linux and Render.
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'citizen' CHECK (role IN ('citizen','officer','admin')),
  created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS grievances (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  tracking_id TEXT UNIQUE,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  title       TEXT NOT NULL,
  description TEXT NOT NULL,
  category    TEXT NOT NULL,
  location    TEXT NOT NULL DEFAULT '',
  status      TEXT NOT NULL DEFAULT 'Submitted'
              CHECK (status IN ('Submitted','Under Review','In Progress','Resolved')),
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS history (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  grievance_id INTEGER NOT NULL REFERENCES grievances(id) ON DELETE CASCADE,
  status       TEXT NOT NULL,
  remark       TEXT NOT NULL DEFAULT '',
  changed_by   INTEGER REFERENCES users(id),
  created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_grievances_user     ON grievances(user_id);
CREATE INDEX IF NOT EXISTS idx_grievances_status   ON grievances(status);
CREATE INDEX IF NOT EXISTS idx_grievances_category ON grievances(category);
CREATE INDEX IF NOT EXISTS idx_history_grievance   ON history(grievance_id);
`;

function openDb(path = process.env.DB_PATH || 'civicpulse.db') {
  const db = new DatabaseSync(path);
  db.exec('PRAGMA foreign_keys = ON;');
  if (path !== ':memory:') db.exec('PRAGMA journal_mode = WAL;');
  db.exec(SCHEMA);

  // db.transaction(fn) returns a function that runs fn atomically (all or nothing).
  db.transaction = (fn) => (...args) => {
    db.exec('BEGIN');
    try {
      const result = fn(...args);
      db.exec('COMMIT');
      return result;
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  };
  return db;
}

module.exports = { openDb };
