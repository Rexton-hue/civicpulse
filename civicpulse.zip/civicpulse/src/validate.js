const { CATEGORIES } = require('./constants');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isString(v) {
  return typeof v === 'string';
}

function validateRegistration(b) {
  const errors = [];
  if (!isString(b.name) || b.name.trim().length < 2 || b.name.trim().length > 60) {
    errors.push('name must be 2 to 60 characters');
  }
  if (!isString(b.email) || !EMAIL_RE.test(b.email.trim()) || b.email.length > 120) {
    errors.push('email must be a valid email address');
  }
  if (!isString(b.password) || b.password.length < 8 || !/[A-Za-z]/.test(b.password) || !/\d/.test(b.password)) {
    errors.push('password must be at least 8 characters and contain a letter and a digit');
  }
  return errors;
}

// partial=true is used for updates: only validate the fields that are present.
function validateGrievanceFields(b, partial = false) {
  const errors = [];
  const has = (k) => b[k] !== undefined;

  if (!partial || has('title')) {
    if (!isString(b.title) || b.title.trim().length < 5 || b.title.trim().length > 120) {
      errors.push('title must be 5 to 120 characters');
    }
  }
  if (!partial || has('description')) {
    if (!isString(b.description) || b.description.trim().length < 10 || b.description.trim().length > 2000) {
      errors.push('description must be 10 to 2000 characters');
    }
  }
  if (!partial || has('category')) {
    if (!CATEGORIES.includes(b.category)) {
      errors.push(`category must be one of: ${CATEGORIES.join(', ')}`);
    }
  }
  if (has('location')) {
    if (!isString(b.location) || b.location.trim().length > 120) {
      errors.push('location must be text up to 120 characters');
    }
  }
  return errors;
}

module.exports = { validateRegistration, validateGrievanceFields };
