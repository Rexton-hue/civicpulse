// Shared constants for the whole backend.
const STATUSES = ['Submitted', 'Under Review', 'In Progress', 'Resolved'];
const CATEGORIES = ['Roads', 'Water Supply', 'Electricity', 'Sanitation', 'Public Safety', 'Other'];
const ROLES = ['citizen', 'officer', 'admin'];

function getJwtSecret() {
  if (process.env.JWT_SECRET) return process.env.JWT_SECRET;
  if (process.env.NODE_ENV === 'production') {
    throw new Error('JWT_SECRET must be set in production');
  }
  return 'dev-only-secret-change-me';
}

module.exports = { STATUSES, CATEGORIES, ROLES, getJwtSecret };
