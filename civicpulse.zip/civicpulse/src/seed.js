const bcrypt = require('bcryptjs');
const { createGrievance } = require('./service');

const DEMO_USERS = [
  { name: 'Asha Admin', email: 'admin@civicpulse.local', password: 'Admin@123', role: 'admin' },
  { name: 'Omar Officer', email: 'officer@civicpulse.local', password: 'Officer@123', role: 'officer' },
  { name: 'Chitra Citizen', email: 'citizen@civicpulse.local', password: 'Citizen@123', role: 'citizen' },
];

const DEMO_GRIEVANCES = [
  { title: 'Large pothole near bus stop', description: 'A deep pothole on the main road is damaging two-wheelers every day.', category: 'Roads', location: 'MG Road' },
  { title: 'Another pothole on MG Road', description: 'Second pothole 50 metres from the first one, water collects here in rain.', category: 'Roads', location: 'MG Road' },
  { title: 'No water supply for 3 days', description: 'Our lane has had no municipal water since Monday morning.', category: 'Water Supply', location: 'Lake View Colony' },
  { title: 'Streetlight not working', description: 'The streetlight outside the park has been off for two weeks.', category: 'Electricity', location: 'Park Street' },
  { title: 'Garbage not collected', description: 'Garbage pickup has been skipped for a week and the smell is spreading.', category: 'Sanitation', location: 'Lake View Colony' },
  { title: 'Open manhole on footpath', description: 'An uncovered manhole is a serious danger to pedestrians at night.', category: 'Public Safety', location: 'Market Road' },
];

// status plan for the demo grievances: [index, [[status, remark], ...]]
const PLAN = {
  1: [['Under Review', 'Inspection scheduled with the roads team']],
  2: [['Under Review', 'Reported to the water board'], ['In Progress', 'Tanker supply started while pipeline is repaired']],
  3: [['Under Review', 'Electrician assigned'], ['In Progress', 'Replacement lamp ordered'], ['Resolved', 'Lamp replaced and tested on site']],
};

function seedDemo(db, rounds = 10) {
  const userIds = {};
  const insertUser = db.prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
  for (const u of DEMO_USERS) {
    userIds[u.role] = Number(insertUser.run(u.name, u.email, bcrypt.hashSync(u.password, rounds), u.role).lastInsertRowid);
  }
  const addHistory = db.prepare('INSERT INTO history (grievance_id, status, remark, changed_by) VALUES (?, ?, ?, ?)');
  const setStatus = db.prepare('UPDATE grievances SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
  DEMO_GRIEVANCES.forEach((g, i) => {
    const id = createGrievance(db, userIds.citizen, g);
    for (const [status, remark] of PLAN[i] || []) {
      setStatus.run(status, id);
      addHistory.run(id, status, remark, userIds.officer);
    }
  });
}

function seedIfEmpty(db) {
  const n = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  if (n === 0) {
    seedDemo(db);
    return true;
  }
  return false;
}

module.exports = { seedDemo, seedIfEmpty, DEMO_USERS };
