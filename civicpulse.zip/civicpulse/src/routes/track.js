const express = require('express');
const { toIso, getHistory } = require('../service');

// Public endpoint: anyone with a tracking ID can see status + officer remarks.
// It deliberately returns no personal details about the citizen.
module.exports = function trackRoutes(db) {
  const router = express.Router();

  router.get('/:trackingId', (req, res) => {
    const g = db
      .prepare('SELECT * FROM grievances WHERE tracking_id = ?')
      .get(String(req.params.trackingId).trim().toUpperCase());
    if (!g) return res.status(404).json({ error: 'No grievance found with that tracking ID' });
    res.json({
      trackingId: g.tracking_id,
      title: g.title,
      category: g.category,
      location: g.location,
      status: g.status,
      createdAt: toIso(g.created_at),
      updatedAt: toIso(g.updated_at),
      history: getHistory(db, g.id),
    });
  });

  return router;
};
