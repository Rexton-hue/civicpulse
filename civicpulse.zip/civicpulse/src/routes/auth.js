const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getJwtSecret } = require('../constants');
const { validateRegistration } = require('../validate');

const ROUNDS = () => Number(process.env.BCRYPT_ROUNDS) || 10;

function signToken(user) {
  return jwt.sign({ id: user.id, role: user.role, name: user.name }, getJwtSecret(), { expiresIn: '8h' });
}

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, role: user.role };
}

module.exports = function authRoutes(db) {
  const router = express.Router();

  // Public registration always creates a citizen. Staff accounts are created by seeding/admin only.
  router.post('/register', (req, res) => {
    const b = req.body || {};
    const errors = validateRegistration(b);
    if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });

    const email = b.email.trim().toLowerCase();
    if (db.prepare('SELECT id FROM users WHERE email = ?').get(email)) {
      return res.status(409).json({ error: 'An account with this email already exists' });
    }
    const hash = bcrypt.hashSync(b.password, ROUNDS());
    const info = db
      .prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'citizen')")
      .run(b.name.trim(), email, hash);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
    res.status(201).json({ token: signToken(user), user: publicUser(user) });
  });

  router.post('/login', (req, res) => {
    const b = req.body || {};
    if (typeof b.email !== 'string' || typeof b.password !== 'string' || !b.email || !b.password) {
      return res.status(400).json({ error: 'email and password are required' });
    }
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(b.email.trim().toLowerCase());
    if (!user || !bcrypt.compareSync(b.password, user.password_hash)) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    res.json({ token: signToken(user), user: publicUser(user) });
  });

  return router;
};
