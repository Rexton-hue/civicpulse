const express = require('express');
const { STATUSES, CATEGORIES } = require('../constants');
const { authenticate, requireRole } = require('../middleware');
const { validateGrievanceFields } = require('../validate');
const { formatGrievance, getHistory, getGrievanceRow, createGrievance } = require('../service');

const isStaff = (user) => user.role === 'officer' || user.role === 'admin';

module.exports = function grievanceRoutes(db) {
  const router = express.Router();
  router.use(authenticate); // every route below needs a valid JWT

  // ---- Create -------------------------------------------------------------
  router.post('/', (req, res) => {
    const b = req.body || {};
    const errors = validateGrievanceFields(b);
    if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });
    const id = createGrievance(db, req.user.id, b);
    res.status(201).json({ ...formatGrievance(getGrievanceRow(db, id)), history: getHistory(db, id) });
  });

  // ---- List: filters, search, pagination ---------------------------------
  router.get('/', (req, res) => {
    const { status, category, q } = req.query;
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 50);

    if (status && !STATUSES.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${STATUSES.join(', ')}` });
    }
    if (category && !CATEGORIES.includes(category)) {
      return res.status(400).json({ error: `category must be one of: ${CATEGORIES.join(', ')}` });
    }

    const where = [];
    const params = [];
    if (!isStaff(req.user)) {
      where.push('g.user_id = ?'); // citizens only ever see their own grievances
      params.push(req.user.id);
    }
    if (status) { where.push('g.status = ?'); params.push(status); }
    if (category) { where.push('g.category = ?'); params.push(category); }
    if (q && String(q).trim()) {
      where.push('(g.title LIKE ? OR g.description LIKE ? OR g.tracking_id LIKE ? OR g.location LIKE ?)');
      const like = `%${String(q).trim()}%`;
      params.push(like, like, like, like);
    }
    const clause = where.length ? 'WHERE ' + where.join(' AND ') : '';

    const total = db
      .prepare(`SELECT COUNT(*) AS n FROM grievances g ${clause}`)
      .get(...params).n;
    const rows = db
      .prepare(
        `SELECT g.*, u.name AS user_name
           FROM grievances g JOIN users u ON u.id = g.user_id
           ${clause}
          ORDER BY g.id DESC LIMIT ? OFFSET ?`
      )
      .all(...params, limit, (page - 1) * limit);

    res.json({
      data: rows.map(formatGrievance),
      page,
      limit,
      total,
      totalPages: Math.max(Math.ceil(total / limit), 1),
    });
  });

  // ---- Dashboard stats (officer/admin). Declared before "/:id". ----------
  router.get('/stats/summary', requireRole('officer', 'admin'), (req, res) => {
    const total = db.prepare('SELECT COUNT(*) AS n FROM grievances').get().n;
    const byStatus = Object.fromEntries(STATUSES.map((s) => [s, 0]));
    for (const r of db.prepare('SELECT status, COUNT(*) AS n FROM grievances GROUP BY status').all()) {
      byStatus[r.status] = r.n;
    }
    const byCategory = db
      .prepare('SELECT category, COUNT(*) AS n FROM grievances GROUP BY category ORDER BY n DESC')
      .all()
      .map((r) => ({ category: r.category, count: r.n }));
    // Recurring issues: same category + same location reported 2+ times and still unresolved.
    const recurring = db
      .prepare(
        `SELECT category, location, COUNT(*) AS n
           FROM grievances
          WHERE location != '' AND status != 'Resolved'
          GROUP BY category, location HAVING n >= 2
          ORDER BY n DESC LIMIT 5`
      )
      .all()
      .map((r) => ({ category: r.category, location: r.location, count: r.n }));
    const resolved = byStatus.Resolved;
    res.json({
      total,
      resolved,
      pending: total - resolved,
      resolutionRate: total ? Math.round((resolved / total) * 1000) / 10 : 0,
      byStatus,
      byCategory,
      recurring,
    });
  });

  // ---- Read one -----------------------------------------------------------
  router.get('/:id', (req, res) => {
    const row = getGrievanceRow(db, Number(req.params.id));
    if (!row) return res.status(404).json({ error: 'Grievance not found' });
    if (!isStaff(req.user) && row.user_id !== req.user.id) {
      return res.status(403).json({ error: 'You do not have permission to view this grievance' });
    }
    res.json({ ...formatGrievance(row), history: getHistory(db, row.id) });
  });

  // ---- Update: owner edits details, officers change status ---------------
  router.put('/:id', (req, res) => {
    const id = Number(req.params.id);
    const g = db.prepare('SELECT * FROM grievances WHERE id = ?').get(id);
    if (!g) return res.status(404).json({ error: 'Grievance not found' });

    const staff = isStaff(req.user);
    if (!staff && g.user_id !== req.user.id) {
      return res.status(403).json({ error: 'You can only modify your own grievances' });
    }

    const b = req.body || {};
    const changesWorkflow = b.status !== undefined || b.remark !== undefined;
    if (changesWorkflow && !staff) {
      return res.status(403).json({ error: 'Only officers or admins can change status or add remarks' });
    }

    const detailKeys = ['title', 'description', 'category', 'location'].filter((k) => b[k] !== undefined);
    if (!detailKeys.length && !changesWorkflow) {
      return res.status(400).json({ error: 'Nothing to update' });
    }
    if (!staff && g.status !== 'Submitted') {
      return res.status(409).json({ error: 'A grievance can only be edited while it is still Submitted' });
    }

    const errors = validateGrievanceFields(b, true);
    if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });

    let newStatus = null;
    if (b.status !== undefined) {
      if (!STATUSES.includes(b.status)) {
        return res.status(400).json({ error: `status must be one of: ${STATUSES.join(', ')}` });
      }
      if (STATUSES.indexOf(b.status) <= STATUSES.indexOf(g.status)) {
        return res
          .status(409)
          .json({ error: `Cannot move from "${g.status}" to "${b.status}". Status can only move forward.` });
      }
      newStatus = b.status;
    }
    const remark = typeof b.remark === 'string' ? b.remark.trim() : '';
    if (b.remark !== undefined && typeof b.remark !== 'string') {
      return res.status(400).json({ error: 'remark must be text' });
    }
    if (remark.length > 500) return res.status(400).json({ error: 'remark must be at most 500 characters' });
    if (newStatus === 'Resolved' && !remark) {
      return res.status(400).json({ error: 'A remark is required when resolving a grievance' });
    }

    const tx = db.transaction(() => {
      for (const k of detailKeys) {
        db.prepare(`UPDATE grievances SET ${k} = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(
          typeof b[k] === 'string' ? b[k].trim() : b[k],
          id
        );
      }
      if (newStatus) {
        db.prepare('UPDATE grievances SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(newStatus, id);
      }
      if (newStatus || remark) {
        db.prepare('INSERT INTO history (grievance_id, status, remark, changed_by) VALUES (?, ?, ?, ?)').run(
          id,
          newStatus || g.status,
          remark,
          req.user.id
        );
        db.prepare('UPDATE grievances SET updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(id);
      }
    });
    tx();

    res.json({ ...formatGrievance(getGrievanceRow(db, id)), history: getHistory(db, id) });
  });

  // ---- Delete (admin only) -----------------------------------------------
  router.delete('/:id', requireRole('admin'), (req, res) => {
    const info = db.prepare('DELETE FROM grievances WHERE id = ?').run(Number(req.params.id));
    if (!info.changes) return res.status(404).json({ error: 'Grievance not found' });
    res.json({ message: 'Grievance deleted' });
  });

  return router;
};
