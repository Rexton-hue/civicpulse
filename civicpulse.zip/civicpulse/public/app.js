/* CivicPulse frontend: plain JavaScript, no build step.
   All server data is inserted with textContent/createTextNode (never innerHTML), so it cannot inject HTML. */
const CATEGORIES = ['Roads', 'Water Supply', 'Electricity', 'Sanitation', 'Public Safety', 'Other'];
const STATUSES = ['Submitted', 'Under Review', 'In Progress', 'Resolved'];

const state = {
  token: localStorage.getItem('cp_token'),
  user: JSON.parse(localStorage.getItem('cp_user') || 'null'),
  page: 1,
  filters: { status: '', category: '', q: '' },
};

// ---------- tiny helpers ----------
function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}
const $app = document.getElementById('app');
const isStaff = () => state.user && (state.user.role === 'officer' || state.user.role === 'admin');
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '');
const chip = (status) => h('span', { class: `chip ${status.split(' ')[0]}` }, status);

let toastTimer;
function toast(msg, bad = false) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show' + (bad ? ' bad' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = 'toast'), 3200);
}

async function api(path, { method = 'GET', body } = {}) {
  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  if (state.token) headers.Authorization = 'Bearer ' + state.token;
  const res = await fetch('/api' + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && state.token) { logout(true); }
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed');
    err.details = data.details || [];
    err.status = res.status;
    throw err;
  }
  return data;
}
const errText = (e) => [e.message, ...(e.details || [])].join('\n');

function setSession(token, user) {
  state.token = token; state.user = user;
  localStorage.setItem('cp_token', token);
  localStorage.setItem('cp_user', JSON.stringify(user));
}
function logout(expired = false) {
  state.token = null; state.user = null;
  localStorage.removeItem('cp_token'); localStorage.removeItem('cp_user');
  if (expired) toast('Session expired, please log in again', true);
  go('track');
}

// ---------- routing ----------
function go(view) { location.hash = view; route(); }
function route() {
  const hash = location.hash.replace('#', '') || 'track';
  renderNav();
  if (hash.startsWith('track')) {
    const id = hash.split('/')[1] || '';
    return renderTrack(id);
  }
  if (hash === 'login') return renderAuth();
  if (hash === 'dashboard') return state.user ? renderDashboard() : renderAuth();
  return renderTrack('');
}
window.addEventListener('hashchange', route);

function renderNav() {
  const nav = document.getElementById('nav');
  nav.replaceChildren(h('button', { class: 'ghost small', onclick: () => go('track') }, 'Track a grievance'));
  if (state.user) {
    nav.append(
      h('button', { class: 'ghost small', onclick: () => go('dashboard') }, isStaff() ? 'Officer dashboard' : 'My grievances'),
      h('span', { class: 'who' }, state.user.name, h('span', { class: 'role' }, state.user.role)),
      h('button', { class: 'ghost small', onclick: () => logout() }, 'Log out')
    );
  } else {
    nav.append(h('button', { class: 'ghost small', onclick: () => go('login') }, 'Log in / Register'));
  }
}

// ---------- public tracking ----------
function timeline(history) {
  return h('ul', { class: 'timeline' }, history.map((e) =>
    h('li', {}, h('strong', {}, e.status), e.remark ? ' | ' + e.remark : '',
      h('div', { class: 'when' }, fmtDate(e.at), e.changedBy ? ' | ' + e.changedBy : ''))
  ));
}

function renderTrack(prefill) {
  const input = h('input', { id: 'track-input', placeholder: 'e.g. GRV-0001', value: prefill || '', 'aria-label': 'Tracking ID' });
  const result = h('div');
  const run = async () => {
    const id = input.value.trim();
    if (!id) return;
    result.replaceChildren(h('p', { class: 'muted' }, 'Looking up...'));
    try {
      const g = await api('/track/' + encodeURIComponent(id));
      result.replaceChildren(h('div', { class: 'card' },
        h('div', { class: 'modal-head' },
          h('div', {}, h('h2', {}, g.trackingId, ' | ', g.title), h('p', { class: 'muted' }, g.category, g.location ? ' | ' + g.location : '', ' | Filed ', fmtDate(g.createdAt))),
          chip(g.status)),
        h('h2', {}, 'Progress'), timeline(g.history)));
    } catch (e) {
      result.replaceChildren(h('p', { class: 'error' }, e.message));
    }
  };
  input.addEventListener('keydown', (e) => e.key === 'Enter' && run());
  $app.replaceChildren(
    h('h1', {}, 'Track your grievance'),
    h('p', { class: 'lead' }, 'Enter the tracking ID you received when you filed it. No login needed.'),
    h('div', { class: 'card' }, h('div', { class: 'row' }, input, h('button', { onclick: run }, 'Track'))),
    result
  );
  if (prefill) run();
}

// ---------- login / register ----------
function renderAuth() {
  let mode = 'login';
  const box = h('div', { class: 'card' });
  const draw = () => {
    const err = h('div', { class: 'error' });
    const f = {
      name: h('input', { id: 'f-name', autocomplete: 'name' }),
      email: h('input', { id: 'f-email', type: 'email', autocomplete: 'email' }),
      password: h('input', { id: 'f-password', type: 'password', autocomplete: mode === 'login' ? 'current-password' : 'new-password' }),
    };
    const submit = async () => {
      err.textContent = '';
      try {
        const body = mode === 'login'
          ? { email: f.email.value, password: f.password.value }
          : { name: f.name.value, email: f.email.value, password: f.password.value };
        const data = await api('/auth/' + mode, { method: 'POST', body });
        setSession(data.token, data.user);
        toast(mode === 'login' ? 'Welcome back, ' + data.user.name : 'Account created');
        go('dashboard');
      } catch (e) { err.textContent = errText(e); }
    };
    box.replaceChildren(
      h('div', { class: 'tabs' },
        h('button', { class: mode === 'login' ? 'active' : '', onclick: () => { mode = 'login'; draw(); } }, 'Log in'),
        h('button', { class: mode === 'register' ? 'active' : '', onclick: () => { mode = 'register'; draw(); } }, 'Register')),
      mode === 'register' && h('div', {}, h('label', { for: 'f-name' }, 'Full name'), f.name),
      h('label', { for: 'f-email' }, 'Email'), f.email,
      h('label', { for: 'f-password' }, 'Password'), f.password,
      mode === 'register' && h('p', { class: 'muted' }, 'At least 8 characters, with a letter and a digit.'),
      h('p', {}, h('button', { onclick: submit }, mode === 'login' ? 'Log in' : 'Create account')),
      err,
      mode === 'login' && h('div', { class: 'hint' }, 'Demo logins: ',
        h('code', {}, 'citizen@civicpulse.local / Citizen@123'), ' | ',
        h('code', {}, 'officer@civicpulse.local / Officer@123'), ' | ',
        h('code', {}, 'admin@civicpulse.local / Admin@123'))
    );
  };
  draw();
  $app.replaceChildren(h('h1', {}, 'Welcome to CivicPulse'), h('p', { class: 'lead' }, 'Log in to file and manage grievances.'), box);
}

// ---------- dashboard ----------
async function renderDashboard() {
  $app.replaceChildren(h('h1', {}, isStaff() ? 'Officer dashboard' : 'My grievances'));
  if (isStaff()) {
    const statsBox = h('div');
    $app.append(statsBox);
    loadStats(statsBox);
  } else {
    $app.append(newGrievanceForm());
  }
  const listBox = h('div');
  $app.append(listBox);
  loadList(listBox);
}

async function loadStats(box) {
  try {
    const s = await api('/grievances/stats/summary');
    const max = Math.max(...Object.values(s.byStatus), 1);
    const catMax = Math.max(...s.byCategory.map((c) => c.count), 1);
    const stat = (num, lbl) => h('div', { class: 'card stat' }, h('div', { class: 'num' }, num), h('div', { class: 'lbl' }, lbl));
    const bars = (rows) => rows.map(([label, n, m]) =>
      h('div', { class: 'bar-row' }, h('span', {}, label), h('div', { class: 'bar' }, h('div', { style: `width:${(n / m) * 100}%` })), h('strong', {}, n)));
    box.replaceChildren(
      h('div', { class: 'grid cols-4' },
        stat(s.total, 'Total grievances'), stat(s.pending, 'Pending'), stat(s.resolved, 'Resolved'), stat(s.resolutionRate + '%', 'Resolution rate')),
      h('div', { class: 'grid cols-2' },
        h('div', { class: 'card' }, h('h2', {}, 'By status'), bars(STATUSES.map((k) => [k, s.byStatus[k], max]))),
        h('div', { class: 'card' }, h('h2', {}, 'By category'), bars(s.byCategory.map((c) => [c.category, c.count, catMax])))),
      h('div', { class: 'card' }, h('h2', {}, 'Recurring unresolved issues'),
        s.recurring.length
          ? h('ul', {}, s.recurring.map((r) => h('li', {}, h('strong', {}, r.category), ' at ', r.location, ': ', r.count, ' open reports')))
          : h('p', { class: 'muted' }, 'No repeated reports for the same place and category.'))
    );
  } catch (e) { box.replaceChildren(h('p', { class: 'error' }, errText(e))); }
}

function newGrievanceForm() {
  const f = {
    title: h('input', { id: 'g-title', maxlength: 120 }),
    category: h('select', { id: 'g-cat' }, CATEGORIES.map((c) => h('option', { value: c }, c))),
    location: h('input', { id: 'g-loc', maxlength: 120, placeholder: 'Street, area or landmark' }),
    description: h('textarea', { id: 'g-desc', maxlength: 2000 }),
  };
  const err = h('div', { class: 'error' });
  const submit = async () => {
    err.textContent = '';
    try {
      const g = await api('/grievances', { method: 'POST', body: {
        title: f.title.value, category: f.category.value, location: f.location.value, description: f.description.value } });
      toast('Filed! Your tracking ID is ' + g.trackingId);
      renderDashboard();
    } catch (e) { err.textContent = errText(e); }
  };
  return h('div', { class: 'card' }, h('h2', {}, 'File a new grievance'),
    h('div', { class: 'grid cols-2' },
      h('div', {}, h('label', { for: 'g-title' }, 'Title'), f.title),
      h('div', {}, h('label', { for: 'g-cat' }, 'Category'), f.category)),
    h('label', { for: 'g-loc' }, 'Location'), f.location,
    h('label', { for: 'g-desc' }, 'Describe the problem'), f.description,
    h('p', {}, h('button', { onclick: submit }, 'Submit grievance')), err);
}

async function loadList(box) {
  const { filters } = state;
  const status = h('select', { 'aria-label': 'Status filter' }, h('option', { value: '' }, 'All statuses'), STATUSES.map((s) => h('option', { value: s, selected: filters.status === s }, s)));
  const category = h('select', { 'aria-label': 'Category filter' }, h('option', { value: '' }, 'All categories'), CATEGORIES.map((c) => h('option', { value: c, selected: filters.category === c }, c)));
  const q = h('input', { placeholder: 'Search title, place or ID', value: filters.q, 'aria-label': 'Search' });
  const apply = () => { state.filters = { status: status.value, category: category.value, q: q.value }; state.page = 1; loadList(box); };
  q.addEventListener('keydown', (e) => e.key === 'Enter' && apply());
  const body = h('div');
  box.replaceChildren(h('div', { class: 'card' },
    h('h2', {}, isStaff() ? 'All grievances' : 'Your grievances'),
    h('div', { class: 'row' }, status, category, q, h('button', { onclick: apply }, 'Filter')), body));

  const params = new URLSearchParams({ page: state.page, limit: 8 });
  for (const [k, v] of Object.entries(state.filters)) if (v) params.set(k, v);
  try {
    const r = await api('/grievances?' + params);
    if (!r.data.length) { body.replaceChildren(h('p', { class: 'empty' }, 'No grievances match.')); return; }
    body.replaceChildren(
      h('div', { class: 'table-wrap' }, h('table', {},
        h('thead', {}, h('tr', {}, ['ID', 'Title', 'Category', isStaff() ? 'Citizen' : 'Location', 'Status', 'Filed', ''].map((t) => h('th', {}, t)))),
        h('tbody', {}, r.data.map((g) => h('tr', {},
          h('td', {}, h('strong', {}, g.trackingId)), h('td', {}, g.title), h('td', {}, g.category),
          h('td', {}, isStaff() ? g.submittedBy.name : g.location), h('td', {}, chip(g.status)), h('td', {}, fmtDate(g.createdAt)),
          h('td', {}, h('button', { class: 'light small', onclick: () => openModal(g.id, box) }, isStaff() ? 'Review' : 'View'))))))),
      h('div', { class: 'pager' },
        h('button', { class: 'light small', disabled: r.page <= 1, onclick: () => { state.page--; loadList(box); } }, 'Previous'),
        h('span', {}, `Page ${r.page} of ${r.totalPages} | ${r.total} total`),
        h('button', { class: 'light small', disabled: r.page >= r.totalPages, onclick: () => { state.page++; loadList(box); } }, 'Next')));
  } catch (e) { body.replaceChildren(h('p', { class: 'error' }, errText(e))); }
}

// ---------- detail / update modal ----------
async function openModal(id, listBox) {
  const root = document.getElementById('modal-root');
  const close = () => root.replaceChildren();
  try {
    const g = await api('/grievances/' + id);
    const err = h('div', { class: 'error' });
    const parts = [
      h('div', { class: 'modal-head' },
        h('div', {}, h('h2', {}, g.trackingId, ' | ', g.title), h('p', { class: 'muted' }, g.category, g.location ? ' | ' + g.location : '', ' | by ', g.submittedBy.name)),
        chip(g.status)),
      h('p', {}, g.description), h('h2', {}, 'History'), timeline(g.history),
    ];
    if (isStaff() && g.status !== 'Resolved') {
      const next = STATUSES.slice(STATUSES.indexOf(g.status) + 1);
      const sel = h('select', { id: 'u-status' }, next.map((s) => h('option', { value: s }, s)));
      const remark = h('textarea', { id: 'u-remark', maxlength: 500, placeholder: 'Remark visible to the citizen (required when resolving)' });
      const save = async () => {
        err.textContent = '';
        try {
          await api('/grievances/' + id, { method: 'PUT', body: { status: sel.value, remark: remark.value } });
          toast('Status updated to ' + sel.value);
          close(); renderDashboard();
        } catch (e) { err.textContent = errText(e); }
      };
      parts.push(h('h2', {}, 'Update status'), h('label', { for: 'u-status' }, 'New status'), sel,
        h('label', { for: 'u-remark' }, 'Remark'), remark, h('p', {}, h('button', { onclick: save }, 'Save update')), err);
    }
    const actions = [h('button', { class: 'light', onclick: close }, 'Close')];
    if (state.user.role === 'admin') {
      actions.push(h('button', { class: 'danger', onclick: async () => {
        if (!confirm('Delete ' + g.trackingId + ' permanently?')) return;
        try { await api('/grievances/' + id, { method: 'DELETE' }); toast('Deleted ' + g.trackingId); close(); renderDashboard(); }
        catch (e) { err.textContent = errText(e); }
      } }, 'Delete')); // admin only
    }
    parts.push(h('div', { class: 'row', style: 'margin-top:1rem' }, actions));
    const overlay = h('div', { class: 'overlay', onclick: (e) => e.target === overlay && close() }, h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' }, parts));
    root.replaceChildren(overlay);
  } catch (e) { toast(errText(e), true); }
}

route();
