// Run with: npm test   (uses Node's built-in test runner, in-memory SQLite, no extra dependencies)
process.env.LOG_REQUESTS = 'off';
process.env.BCRYPT_ROUNDS = '4';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const bcrypt = require('bcryptjs');
const { openDb } = require('../src/db');
const { createApp } = require('../src/app');

let server, base, db;
const tokens = {};
const ids = {};

async function call(method, path, { token, body } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = 'Bearer ' + token;
  const res = await fetch(base + path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  return { status: res.status, body: await res.json().catch(() => ({})) };
}

const sample = (over = {}) => ({
  title: 'Pothole outside school gate',
  description: 'A large pothole has formed right outside the main school gate.',
  category: 'Roads',
  location: 'School Lane',
  ...over,
});

async function login(email, password) {
  const r = await call('POST', '/api/auth/login', { body: { email, password } });
  return r.body.token;
}

before(async () => {
  db = openDb(':memory:');
  const hash = bcrypt.hashSync('Passw0rd!', 4);
  const add = db.prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
  add.run('Olive Officer', 'officer@test.local', hash, 'officer');
  add.run('Adam Admin', 'admin@test.local', hash, 'admin');
  server = createApp(db).listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  tokens.officer = await login('officer@test.local', 'Passw0rd!');
  tokens.admin = await login('admin@test.local', 'Passw0rd!');
});

after(() => {
  server.close();
  db.close();
});

// ---------------------------------------------------------------- Auth (8)
test('01 register creates a citizen and returns a token', async () => {
  const r = await call('POST', '/api/auth/register', { body: { name: 'Cara Citizen', email: 'Cara@Test.local', password: 'Secret123' } });
  assert.equal(r.status, 201);
  assert.equal(r.body.user.role, 'citizen');
  assert.equal(r.body.user.email, 'cara@test.local'); // normalised to lower case
  assert.ok(r.body.token);
  assert.equal(r.body.user.password_hash, undefined);
  tokens.cara = r.body.token;
});

test('02 register ignores an attempt to self-assign the admin role', async () => {
  const r = await call('POST', '/api/auth/register', { body: { name: 'Sneaky Sam', email: 'sam@test.local', password: 'Secret123', role: 'admin' } });
  assert.equal(r.status, 201);
  assert.equal(r.body.user.role, 'citizen');
  tokens.sam = r.body.token;
});

test('03 register rejects a weak password', async () => {
  const r = await call('POST', '/api/auth/register', { body: { name: 'Weak Wendy', email: 'wendy@test.local', password: 'short' } });
  assert.equal(r.status, 400);
  assert.ok(r.body.details.some((d) => d.includes('password')));
});

test('04 register rejects an invalid email', async () => {
  const r = await call('POST', '/api/auth/register', { body: { name: 'Bad Email', email: 'not-an-email', password: 'Secret123' } });
  assert.equal(r.status, 400);
  assert.ok(r.body.details.some((d) => d.includes('email')));
});

test('05 register rejects a duplicate email with 409', async () => {
  const r = await call('POST', '/api/auth/register', { body: { name: 'Cara Again', email: 'cara@test.local', password: 'Secret123' } });
  assert.equal(r.status, 409);
});

test('06 login succeeds with correct credentials', async () => {
  const r = await call('POST', '/api/auth/login', { body: { email: 'cara@test.local', password: 'Secret123' } });
  assert.equal(r.status, 200);
  assert.ok(r.body.token);
});

test('07 login fails for a wrong password and for an unknown email', async () => {
  const wrong = await call('POST', '/api/auth/login', { body: { email: 'cara@test.local', password: 'WrongPass1' } });
  const unknown = await call('POST', '/api/auth/login', { body: { email: 'nobody@test.local', password: 'Secret123' } });
  assert.equal(wrong.status, 401);
  assert.equal(unknown.status, 401);
  assert.equal(wrong.body.error, unknown.body.error); // no hint about which part was wrong
});

test('08 protected routes reject missing and invalid tokens', async () => {
  const none = await call('GET', '/api/grievances');
  const bad = await call('GET', '/api/grievances', { token: 'not.a.real.token' });
  assert.equal(none.status, 401);
  assert.equal(bad.status, 401);
});

// ------------------------------------------------------- Create + track (6)
test('09 citizen files a grievance and gets a GRV tracking ID', async () => {
  const r = await call('POST', '/api/grievances', { token: tokens.cara, body: sample() });
  assert.equal(r.status, 201);
  assert.match(r.body.trackingId, /^GRV-\d{4}$/);
  assert.equal(r.body.status, 'Submitted');
  assert.equal(r.body.history.length, 1);
  ids.first = r.body.id;
  ids.firstTracking = r.body.trackingId;
});

test('10 create rejects bad input (short title, bad category)', async () => {
  const shortTitle = await call('POST', '/api/grievances', { token: tokens.cara, body: sample({ title: 'abc' }) });
  const badCategory = await call('POST', '/api/grievances', { token: tokens.cara, body: sample({ category: 'Aliens' }) });
  assert.equal(shortTitle.status, 400);
  assert.equal(badCategory.status, 400);
});

test('11 public tracking works without login and exposes no personal data', async () => {
  const r = await call('GET', '/api/track/' + ids.firstTracking.toLowerCase()); // case-insensitive
  assert.equal(r.status, 200);
  assert.equal(r.body.trackingId, ids.firstTracking);
  assert.equal(r.body.status, 'Submitted');
  const text = JSON.stringify(r.body);
  assert.ok(!text.includes('cara@test.local'));
  assert.equal(r.body.submittedBy, undefined);
});

test('12 tracking an unknown ID returns 404', async () => {
  const r = await call('GET', '/api/track/GRV-9999');
  assert.equal(r.status, 404);
});

test('13 seed more grievances for list tests', async () => {
  const a = await call('POST', '/api/grievances', { token: tokens.cara, body: sample({ title: 'Water pipe leaking badly', category: 'Water Supply', location: 'Canal Road' }) });
  const b = await call('POST', '/api/grievances', { token: tokens.cara, body: sample({ title: 'Garbage heap on corner', category: 'Sanitation', location: 'Market Road' }) });
  const c = await call('POST', '/api/grievances', { token: tokens.sam, body: sample({ title: 'Broken streetlight pole', category: 'Electricity', location: 'Park Street' }) });
  assert.deepEqual([a.status, b.status, c.status], [201, 201, 201]);
  ids.water = a.body.id;
  ids.sam = c.body.id;
});

test('14 grievance endpoints require authentication', async () => {
  const r = await call('POST', '/api/grievances', { body: sample() });
  assert.equal(r.status, 401);
});

// ---------------------------------------------------------- List queries (6)
test('15 a citizen only sees their own grievances', async () => {
  const r = await call('GET', '/api/grievances', { token: tokens.sam });
  assert.equal(r.status, 200);
  assert.equal(r.body.total, 1);
  assert.equal(r.body.data[0].title, 'Broken streetlight pole');
});

test('16 an officer sees every grievance', async () => {
  const r = await call('GET', '/api/grievances', { token: tokens.officer });
  assert.equal(r.body.total, 4);
});

test('17 filter by category', async () => {
  const r = await call('GET', '/api/grievances?category=Water%20Supply', { token: tokens.officer });
  assert.equal(r.body.total, 1);
  assert.equal(r.body.data[0].category, 'Water Supply');
});

test('18 search matches title, location and tracking ID', async () => {
  const byTitle = await call('GET', '/api/grievances?q=garbage', { token: tokens.officer });
  const byPlace = await call('GET', '/api/grievances?q=Canal', { token: tokens.officer });
  const byId = await call('GET', '/api/grievances?q=' + ids.firstTracking, { token: tokens.officer });
  assert.equal(byTitle.body.total, 1);
  assert.equal(byPlace.body.total, 1);
  assert.equal(byId.body.total, 1);
});

test('19 pagination returns page metadata', async () => {
  const p1 = await call('GET', '/api/grievances?limit=3&page=1', { token: tokens.officer });
  const p2 = await call('GET', '/api/grievances?limit=3&page=2', { token: tokens.officer });
  assert.equal(p1.body.data.length, 3);
  assert.equal(p1.body.totalPages, 2);
  assert.equal(p2.body.data.length, 1);
  assert.equal(p2.body.page, 2);
});

test('20 an invalid status filter returns 400', async () => {
  const r = await call('GET', '/api/grievances?status=Exploded', { token: tokens.officer });
  assert.equal(r.status, 400);
});

// ------------------------------------------------------- Update + status (6)
test('21 the owner can edit details while Submitted', async () => {
  const r = await call('PUT', '/api/grievances/' + ids.first, { token: tokens.cara, body: { location: 'School Lane, Gate 2' } });
  assert.equal(r.status, 200);
  assert.equal(r.body.location, 'School Lane, Gate 2');
});

test('22 another citizen cannot modify or read it', async () => {
  const edit = await call('PUT', '/api/grievances/' + ids.first, { token: tokens.sam, body: { title: 'Hijacked title here' } });
  const read = await call('GET', '/api/grievances/' + ids.first, { token: tokens.sam });
  assert.equal(edit.status, 403);
  assert.equal(read.status, 403);
});

test('23 a citizen cannot change status', async () => {
  const r = await call('PUT', '/api/grievances/' + ids.first, { token: tokens.cara, body: { status: 'Resolved', remark: 'done' } });
  assert.equal(r.status, 403);
});

test('24 an officer moves status forward and the remark shows in public tracking', async () => {
  const r = await call('PUT', '/api/grievances/' + ids.first, { token: tokens.officer, body: { status: 'Under Review', remark: 'Site visit booked' } });
  assert.equal(r.status, 200);
  assert.equal(r.body.status, 'Under Review');
  const t = await call('GET', '/api/track/' + ids.firstTracking);
  assert.equal(t.body.status, 'Under Review');
  assert.equal(t.body.history.length, 2);
  assert.equal(t.body.history[1].remark, 'Site visit booked');
});

test('25 status cannot move backwards, resolving needs a remark, and owners cannot edit after review starts', async () => {
  const back = await call('PUT', '/api/grievances/' + ids.first, { token: tokens.officer, body: { status: 'Submitted' } });
  const noRemark = await call('PUT', '/api/grievances/' + ids.first, { token: tokens.officer, body: { status: 'Resolved' } });
  const locked = await call('PUT', '/api/grievances/' + ids.first, { token: tokens.cara, body: { title: 'Trying to edit later' } });
  assert.equal(back.status, 409);
  assert.equal(noRemark.status, 400);
  assert.equal(locked.status, 409);
});

test('26 filter by status after an update', async () => {
  const r = await call('GET', '/api/grievances?status=Under%20Review', { token: tokens.officer });
  assert.equal(r.body.total, 1);
  assert.equal(r.body.data[0].id, ids.first);
});

// ----------------------------------------------------- Stats + delete (3)
test('27 stats are for staff only and report the resolution rate', async () => {
  const forbidden = await call('GET', '/api/grievances/stats/summary', { token: tokens.cara });
  assert.equal(forbidden.status, 403);

  await call('PUT', '/api/grievances/' + ids.water, { token: tokens.officer, body: { status: 'Resolved', remark: 'Pipe repaired' } });
  const r = await call('GET', '/api/grievances/stats/summary', { token: tokens.officer });
  assert.equal(r.status, 200);
  assert.equal(r.body.total, 4);
  assert.equal(r.body.resolved, 1);
  assert.equal(r.body.resolutionRate, 25);
  assert.equal(r.body.byStatus['Under Review'], 1);
});

test('28 only an admin can delete a grievance', async () => {
  const asOfficer = await call('DELETE', '/api/grievances/' + ids.sam, { token: tokens.officer });
  const asCitizen = await call('DELETE', '/api/grievances/' + ids.sam, { token: tokens.sam });
  assert.equal(asOfficer.status, 403);
  assert.equal(asCitizen.status, 403);
});

test('29 admin delete removes the grievance and its history; second delete is 404', async () => {
  const del = await call('DELETE', '/api/grievances/' + ids.first, { token: tokens.admin });
  const again = await call('DELETE', '/api/grievances/' + ids.first, { token: tokens.admin });
  const track = await call('GET', '/api/track/' + ids.firstTracking);
  const orphans = db.prepare('SELECT COUNT(*) AS n FROM history WHERE grievance_id = ?').get(ids.first).n;
  assert.equal(del.status, 200);
  assert.equal(again.status, 404);
  assert.equal(track.status, 404);
  assert.equal(orphans, 0); // ON DELETE CASCADE
});
